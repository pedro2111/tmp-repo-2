# Seguridade Card Web Component

Este é um Web Component desenvolvido com **Lit** baseado no design de card de seguridade. Ele é agnóstico a framework e pode ser utilizado em microfrontends feitos em **React**, **Angular**, **Vue** ou HTML puro.

## Propriedades (Attributes)

| Propriedade | Tipo | Descrição | Valor Padrão |
| :--- | :--- | :--- | :--- |
| `title` | String | Título principal do card | `''` |
| `product` | String | Nome do produto | `''` |
| `status` | String | Status do produto (`vigente`, `pendente`, `inativo`) | `'vigente'` |
| `policy` | String | Número da apólice | `''` |
| `validity` | String | Data de vigência | `''` |
| `value` | String | Valor formatado (ex: `R$ 12.300,00`) | `''` |
| `showValue` | Boolean | Controla a visibilidade do valor | `true` |
| `detailsLabel` | String | Texto do link de detalhes | `'Mais Detalhes'` |

## Eventos Customizados

- `toggle-visibility`: Disparado quando o ícone de olho é clicado.
- `details-click`: Disparado quando o link "Mais Detalhes" é clicado.

---

## Como utilizar em React

Para usar Web Components no React, você deve importar o arquivo do componente e utilizá-lo como uma tag HTML comum.

```jsx
import React, { useEffect, useRef } from 'react';
import './path/to/seguridade-card.es.js'; // Importa o Web Component

const MyComponent = () => {
  const cardRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    
    // Escutando eventos customizados
    const handleDetails = (e) => console.log('Detalhes da apólice:', e.detail.policy);
    
    card.addEventListener('details-click', handleDetails);
    return () => card.removeEventListener('details-click', handleDetails);
  }, []);

  return (
    <seguridade-card
      ref={cardRef}
      title="Vida Mulher"
      product="Vida"
      status="vigente"
      policy="12134465"
      validity="22/02/2024"
      value="R$ 12.300,00"
    ></seguridade-card>
  );
};

export default MyComponent;
```

---

## Como utilizar em Angular (v16+)

No Angular, você precisa permitir o uso de elementos customizados no seu módulo ou componente.

### 1. Configurar o Módulo
Adicione `CUSTOM_ELEMENTS_SCHEMA` ao seu `AppModule` ou componente standalone.

```typescript
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
import { BrowserModule } from '@angular/platform-browser';
import { AppComponent } from './app.component';

@NgModule({
  declarations: [AppComponent],
  imports: [BrowserModule],
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Importante!
  bootstrap: [AppComponent]
})
export class AppModule { }
```

### 2. Importar o Componente
No seu `main.ts` ou no componente onde será usado:
```typescript
import './path/to/seguridade-card.es.js';
```

### 3. Utilizar no Template
```html
<seguridade-card
  [attr.title]="'Vida Mulher'"
  [attr.product]="'Vida'"
  [attr.status]="'pendente'"
  [attr.policy]="'12134465'"
  [attr.validity]="'22/02/2024'"
  [attr.value]="'R$ 12.300,00'"
  (details-click)="onDetailsClick($event)"
></seguridade-card>
```

---

## Como rodar o projeto localmente

1. Instale as dependências: `npm install`
2. Gere o build: `npm run build`
3. Os arquivos gerados estarão na pasta `dist/`.
