import { defineConfig } from 'vite';

export default defineConfig({
  build: {
    lib: {
      entry: 'SeguridadeCard.js',
      name: 'SeguridadeCard',
      fileName: (format) => `seguridade-card.${format}.js`,
      formats: ['es', 'umd']
    },
    rollupOptions: {
      // Certifique-se de tratar dependências que não devem ser empacotadas
      external: [],
      output: {
        globals: {
          lit: 'Lit'
        }
      }
    }
  }
});
