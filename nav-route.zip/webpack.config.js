const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-react");

module.exports = (webpackConfigEnv, argv) => {
  const defaultConfig = singleSpaDefaults({
    orgName: "caixa",
    projectName: "navbar",
    webpackConfigEnv,
    argv,
    outputSystemJS: false, // ✅ mantém o formato ESM
  });

  return merge(defaultConfig, {
    externals: {}, // ✅ remove React e ReactDOM dos externals (eles serão empacotados)
    output: {
      filename: "caixa-navbar.js",
      libraryTarget: "module", // ✅ formato ESM (importável via import())
      scriptType: "module", // ✅ importante para browsers modernos
    },
    experiments: {
      outputModule: true, // ✅ habilita saída como módulo
    },
    devServer: {
      port: 8500,
      headers: {
        "Access-Control-Allow-Origin": "*", // ✅ evita CORS ao servir pelo host
      },
    },
  });
};
