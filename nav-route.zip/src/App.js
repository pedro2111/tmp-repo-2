import React from "react";
import { BrowserRouter, Routes, Route, Link } from "react-router-dom";
/*export default function App(props) {
  return  (
       <Routes/>
   );
}*/

function Home() {
  return <h2>🏠 Página Inicial</h2>;
}

function Sobre() {
  return <h2>ℹ️ Sobre</h2>;
}

function Usuario() {
  return <h2>👤 Usuário</h2>;
}

export default function App() {
  return (
    <BrowserRouter basename="/">
      <div>
        <h1>Navbar MFE</h1>
        <nav>
          <ul>
            <li><Link to="/">Início</Link></li>
            <li><Link to="/welcome">Welcome</Link></li>
            <li><Link to="/usuario">Usuário</Link></li>
          </ul>
        </nav>

        <Routes>
          <Route path="/" element={<Home />} />
          <Route path="/welcome" />
          <Route path="/usuario" element={<Usuario />} />
        </Routes>
      </div>
    </BrowserRouter>
  );
}
