import React from "react";
import { Route, BrowserRouter } from "react-router-dom";

import Navbar from "./components/Navbar";



const Routes = () => {
   return(
       <BrowserRouter basename="/mfe-navbar">
           <Route component = { Navbar } path="/" />
           <Route  path="/sobre" />
           <Route  path="/usuario" />
       </BrowserRouter>
   )
}

export default Routes;