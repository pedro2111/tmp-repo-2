const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-ts");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");
const { webpack } = require("webpack");
const Dotenv = require("dotenv-webpack");
const varAmbienteDev = require("./src/environments/environment.js");
const varAmbienteProd = require("./src/environments/environment.prod.js");

module.exports = (webpackConfigEnv, argv) => {
  const orgName = "caixa";
  const defaultConfig = singleSpaDefaults({
    orgName,
    projectName: "sigpf-host",
    webpackConfigEnv,
    argv,
    disableHtmlGeneration: true,
  });
  let varEnvPath;
  let varAmbiente;
  let templateFile = "src/index.ejs"; // Template padrão com CDN
  
  if (webpackConfigEnv.isLocal) {
    varEnvPath = "src/environments/environment.env";
    varAmbiente = varAmbienteDev;
  } else {
    varEnvPath = "src/environments/environment.prod.env";
    varAmbiente = varAmbienteProd;
  }
  
  // Se useLocalAssets estiver definido, usar template com assets locais
  if (webpackConfigEnv.useLocalAssets) {
    templateFile = "src/index-local.ejs";
  }
  
  return merge(defaultConfig, {
    plugins: [
      new Dotenv({
        path: varEnvPath,
      }),
      new HtmlWebpackPlugin({
        inject: false,
        template: templateFile,
        publicPath: "public",
        favicon: "public/favicon.ico",
        templateParameters: {
          varAmbiente: varAmbiente,
        },
      }),
    ],
    devServer: {
      static: "./public",
      hot: true,
      watchFiles: ["src/**/*"],
      port: 9000,
    },
  });
};
