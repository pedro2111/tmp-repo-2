export function loadFontFacesSPA(deployUrl: string) {

  const style = document.createElement('style');
  style.type = 'text/css';
  
  const fontFaces = `
    @font-face {
      font-family: 'Caixa STD';
      font-weight: 400;
      font-style: normal;
      font-display: block;
      src: url('${deployUrl}CAIXAStd-Regular.woff2') format('woff2'),
      url('${deployUrl}CAIXAStd-Regular.woff') format('woff');
    }
  
    @font-face {
      font-family: 'Caixa STD';
      font-weight: 600;
      font-style: normal;
      font-display: block;
      src: url('${deployUrl}CAIXAStd-SemiBold.woff2') format('woff2'),
      url('${deployUrl}CAIXAStd-SemiBold.woff') format('woff');
    }
  
    @font-face {
      font-family: 'Caixa STD';
      font-weight: 600;
      font-style: italic;
      font-display: block;
      src: url('${deployUrl}CAIXAStd-SemiBoldItalic.woff2') format('woff2'),
      url('${deployUrl}CAIXAStd-SemiBoldItalic.woff') format('woff');
    }
  
    @font-face {
      font-family: 'Caixa STD';
      font-weight: 700;
      font-style: normal;
      font-display: block;
      src: url('${deployUrl}CAIXAStd-Bold.woff2') format('woff2'),
      url('${deployUrl}CAIXAStd-Bold.woff') format('woff');
    }
  
    @font-face {
      font-family: 'Caixa STD';
      font-weight: 700;
      font-style: italic;
      font-display: block;
      src: url('${deployUrl}CAIXAStd-BoldItalic.woff2') format('woff2'),
      url('${deployUrl}CAIXAStd-BoldItalic.woff') format('woff');
    }
  
    @font-face {
      font-family: "Material Icons";
      font-style: normal;
      font-weight: 400;
      font-display: block;
      src: url('${deployUrl}material-icons.woff2') format('woff2');
    }
  
    @font-face {
      font-family: "Material Icons Outlined";
      font-style: normal;
      font-weight: 400;
      font-display: block;
      src: url('${deployUrl}material-icons-outlined.woff2') format('woff2');
    }
  
  `;
  style.innerHTML = fontFaces;
  document.head.appendChild(style);
  
}