import { registerApplication, start, LifeCycles } from "single-spa";
import { ApplicationInsights } from '@microsoft/applicationinsights-web';
import * as moment from "moment";

//Código para adição de monitoração do Microsoft App Insights
if (process.env.appInsightsAtivo == "true") {
    const appInsights = new ApplicationInsights({
        config: {
            connectionString: process.env.appInsightsConnectionString,
            enableAutoRouteTracking: true
        }
    });
    appInsights.addTelemetryInitializer((envelope) => {
        let itemTags = envelope.tags;
        if (itemTags) {
            itemTags = itemTags || [];
            itemTags['ai.cloud.role'] = process.env.appInsightsRoleName;
        }
    });
    appInsights.loadAppInsights();
    appInsights.trackPageView();
}

addEventListener("@caixa/keycloak/login", (event: any) => {    
    let jsonApps = JSON.parse(sessionStorage.getItem("json-apps"));
    for (let appl of jsonApps) {
        registerApplication({
            name: appl.application,
            app: () => System.import<LifeCycles>(appl.application),
            activeWhen: (location) => ativarApp(location, appl)
        });
    }
    start();
    gerenciarCache();
});

function ativarApp(location: Location, appl: any) {
    let rotaAppl = appl.route.replace(/\/+$/, '').toLowerCase();
    let rotaSelecionada = location.pathname.replace(/\/+$/, '').toLowerCase();
    if (comparaRotas(rotaAppl, rotaSelecionada)) {
        let objPermissoes = verificarPermissoes(rotaAppl);
        if (objPermissoes == null) {
            //erro ao buscar permissões para esta rota
            gerenciarMensagemUsuario(2, "Plataforma Unificada: ocorreu um erro ao acessar esta funcionalidade.");
        } else {
            if (objPermissoes.length == 0) {
                //sem permissões para esta rota
                gerenciarMensagemUsuario(1, "Plataforma Unificada: Acesso negado.");
                return false;
            }

            let nomeRotaSelecionada = sessionStorage.getItem("nome-rota-selecionada");
            if (escolherApp(objPermissoes, nomeRotaSelecionada) == appl.application) {
                gerenciarMensagemUsuario(0);
                sessionStorage.setItem("nome-rota-selecionada", appl.application);
                return true;
            }
        }
    }
    return false;
}

function comparaRotas(rotaApp: string, rotaLocation: string) {
    if (rotaApp == rotaLocation) {
        return true;
    } else {
        if (rotaApp.length >= rotaLocation.length) {
            return false;
        } else {
            if (rotaLocation.startsWith(rotaApp) && rotaLocation.charAt(rotaApp.length) == '/') {
                return true;
            } else {
                return false;
            }
        }
    }
}

function verificarPermissoes(rotaAppl: string) {
    let jsonRetorno = null;
    let listaPermissoes = getItemCachePermissoes("permissoes" + rotaAppl);
    switch (listaPermissoes) {
        case null:
            let urlPermissoes = process.env.urlBackendMenudinamico + "/v1/rotas?descricaoRota=" + rotaAppl;
            const request = new XMLHttpRequest();
            request.open("GET", urlPermissoes, false);
            request.setRequestHeader("Authorization", "Bearer " + sessionStorage.getItem("token"));
            request.send(null);
            switch (request.status) {
                case 200:
                    jsonRetorno = request.response;
                    setItemCachePermissoes("permissoes" + rotaAppl, jsonRetorno);
                    break;
                case 204:
                    jsonRetorno = "[]";
                    setItemCachePermissoes("permissoes" + rotaAppl, "sem permissoes");
                    break;
            }
            break;
        case "sem permissoes":
            jsonRetorno = "[]";
            break;
        default:
            jsonRetorno = listaPermissoes;
            break;
    }
    if (jsonRetorno != null) {
        let objRetorno = JSON.parse(jsonRetorno);
        let vetPermissoes = new Array<any>();
        for (let permissao of objRetorno) {
            if (permissao.isAcessoPermitido) {
                vetPermissoes[permissao.nomeRota] = permissao.descricaoRota.toLowerCase();
            }
        }
        return Object.entries(vetPermissoes);
    }
    return null;
}

function escolherApp(objPermissoes: any, nomeRotaSelecionada: string) {
    //primeira possibilidade: a aplicação teve seu nome de rota indicado pelo navbar:
    for (const obj of objPermissoes) {
        if (obj[0] == nomeRotaSelecionada) {
            return obj[0];
        }
    }

    //segunda e terceira possibilidades: só existe uma aplicação com acesso para a rota ou 
    //existem apps distintos com acesso permitido. Em ambos os casos, o critério de escolha
    //é por ordem alfabética:
    objPermissoes.sort(function (a: any, b: any) {
        if (a[0] > b[0]) {
            return 1;
        }
        if (a[0] < b[0]) {
            return -1;
        }
        return 0;
    })
    return objPermissoes[0][0];
}

function getItemCachePermissoes(chave: string) {
    return sessionStorage.getItem(chave);
}

function setItemCachePermissoes(chave: string, valor: any) {
    return sessionStorage.setItem(chave, valor);
}

function capturarVersaoHost() {
    const {version: appVersion} = require("../package.json");
    return sessionStorage.setItem("appVersionHost", appVersion);
}

function gerenciarCache() {
    capturarVersaoHost();
    console.log("[Session Storage] Cache management started", moment.default(new Date()).format("YYYY-MM-DD HH:mm:ss"));
    setInterval(() => {
        const dataHoraAtual = new Date();
        console.log("[Session Storage] Cache cleaned", moment.default(dataHoraAtual).format("YYYY-MM-DD HH:mm:ss"));
        for (let item of Object.keys(sessionStorage)) {
            if (item.startsWith("permissoes")) {
                sessionStorage.removeItem(item);
            }
            if (item.startsWith("bioPF_")) {
                sessionStorage.removeItem(item);
            }
            if (item.startsWith("VLDC_BMTRC")) {
                sessionStorage.removeItem(item);
            }
        }
        const dataHoraExpiracao = dataHoraAtual.setMilliseconds(dataHoraAtual.getMilliseconds() + Number(process.env.cacheTimeExpiration));
        console.log("[Session Storage] Next cache expiration will be at", moment.default(dataHoraExpiracao).format("YYYY-MM-DD HH:mm:ss"));
    }, Number(process.env.cacheTimeExpiration));
}

function gerenciarMensagemUsuario(tipoMensagem: number, mensagem: string = "") {
    switch (tipoMensagem) {
        case 0:
            //sem mensagems a serem transmitidas
            document.getElementById("mensagem-acesso-negado").style.visibility = "hidden";
            document.getElementById("mensagem-erro").style.visibility = "hidden";
            break;
        case 1:
            //mensagem: sem permissão
            let divPermissao = document.getElementById("mensagem-acesso-negado");
            let divErro = document.getElementById("mensagem-erro");
            let divPai = document.getElementById("main-content");
            divPermissao.style.visibility = "visible";
            divErro.style.visibility = "hidden";
            document.getElementById("texto-mensagem-acesso-negado").innerHTML = mensagem;
            divPai.insertBefore(divPermissao, divErro);
            break;
        case 2:
            //mensagem: erro
            divPermissao = document.getElementById("mensagem-acesso-negado");
            divErro = document.getElementById("mensagem-erro");
            divPai = document.getElementById("main-content");
            divPermissao.style.visibility = "hidden";
            divErro.style.visibility = "visible";
            document.getElementById("texto-mensagem-erro").innerHTML = mensagem;
            divPai.insertBefore(divErro, divPermissao);
            break;
    }

}