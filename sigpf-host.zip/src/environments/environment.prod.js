//Desenvolvedor: NÃO EDITAR ESTE ARQUIVO caso você esteja desenvolvendo MFEs
//Este arquivo deve ser editado somente caso o host esteja sendo alterado.
const listaMFEs = `[]`;
const variaveisAmbiente = {
  urlHost: "__SIPNC_HOST_URL__",
  listaMFEs: listaMFEs,
  isBuscarMFEsDinamicos: "true",
};
module.exports = variaveisAmbiente;

/*
  urlCDN: endereço do CDN;
  urlHost: endereço do host;
  urlCore: endereço do core;
  urlNavBar: endereço do navbar;
  urlMenuDinamico: endereço do backend do menu dinâmico;
  listaMFEs: lista de MFEs a serem carregados pelo host;
  isBuscarMFEsDinamicos: flag que indica se a lista de MFEs a serem carregados virá da variável "listaMFEs" ou
                         do backend do menu dinâmico;
*/
