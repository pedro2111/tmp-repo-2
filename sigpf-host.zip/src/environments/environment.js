//Desenvolvedor: EDITAR ESTE ARQUIVO APENAS caso você esteja desenvolvendo MFEs.
//O seu MFE deve ser adicionado na variável "listaMFEs" abaixo.
//NÃO é necessário editar a variável "variaveisAmbiente".
//Após editar este arquivo, é necessário que o comando npm start seja executado novamente,
//pois a atualização automática de alterações NÃO funciona para este caso.
let listaMFEs = `[
  {
    "application": "cvp-poc-superapp",
    "route": "/cvp-poc",
    "path": "./assets/mfes/cvp-poc-superapp/CVP-POC-SuperApp.js"
  }  
]`;

let variaveisAmbiente = {  
  urlHost: "//localhost:9000/caixa-sigpf-host.js",
  listaMFEs: listaMFEs,
  isBuscarMFEsDinamicos: "false"
};
module.exports = variaveisAmbiente;

/*Legenda:
  urlCDN: endereço do CDN;
  urlHost: endereço do host;
  urlCore: endereço do core; //Editar esta variável quando estiver modificando o core: //localhost:4000;
  urlNavBar: endereço do navbar; //Editar esta variável quando estiver modificando o navbar: //localhost:4201;
  urlMenuDinamico: endereço do backend do menu dinâmico;
  listaMFEs: lista de MFEs a serem carregados pelo host;
  isBuscarMFEsDinamicos: flag que indica se a lista de MFEs a serem carregados virá da variável "listaMFEs" ou
                         do backend do menu dinâmico;
*/
