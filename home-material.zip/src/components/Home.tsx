import React from "react";
import Card from './Card';
import SubHeader from "./SubHeader";

export default function Home() {
    const cardData = {
        title: "Vida Mulher",
        category: "Vida",
        status: "VIGENTE",
        policyNumber: "12134465",
        effectiveDate: "22/02/2024",
        value: "R$ 12.300,00"
    };

    return (
        <>
            <SubHeader />
            <Card {...cardData} />
            
        </>
    )
}