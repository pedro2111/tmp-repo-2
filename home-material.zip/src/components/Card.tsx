import React from "react";
import { Box, Typography, Stack, styled } from '@mui/material';

interface CardProps {
    title: string;
    category: string;
    status: string;
    policyNumber: string;
    effectiveDate: string;
    value: string;
}

// --- Styled Components ---

const CardWrapper = styled(Box)(({ theme }) => ({
    width: 362,
    height: 280,
    position: 'relative',
    background: 'white',
    boxShadow: '4px 4px 8px rgba(140.25, 138.50, 138.50, 0.25)',
    overflow: 'hidden',
    borderRadius: (theme.shape.borderRadius as number) * 2, // Using theme for consistency
    border: '1px solid #EBF1F2',
    fontFamily: 'CAIXA Std, sans-serif', // Set base font family here
}));

const CardHeader = styled(Stack)({
    position: 'absolute',
    width: 311,
    height: 44,
    left: 25,
    top: 24,
});

const GradientDivider = styled(Box)({
    position: 'absolute',
    width: 311,
    height: 3,
    left: 25,
    top: 85,
    background: 'linear-gradient(90deg, #005CA9 0%, #54BBAB 61%, white 100%)',
    borderRadius: 24,
});

const InfoSection = styled(Stack)({
    position: 'absolute',
    width: 313,
    left: 24,
    top: 95,
});

const ValueSection = styled(Stack)({
    position: 'absolute',
    width: 313,
    height: 63,
    left: 24,
    top: 147,
    borderTop: '1px solid #EBF1F2',
    borderBottom: '1px solid #EBF1F2',
});

const DetailsLink = styled(Stack)({
    position: 'absolute',
    left: 24,
    top: 222,
    paddingLeft: 3,
    cursor: 'pointer', // Make it look clickable
});

const ArrowIcon = styled(Box)({
    width: 24,
    height: 24,
    position: 'relative',
    '&::after': {
        content: '""',
        position: 'absolute',
        width: 6,
        height: 6,
        left: 9,
        top: 9,
        borderRight: '2.50px solid #005CA9',
        borderBottom: '2.50px solid #005CA9',
        transform: 'rotate(-45deg)',
    }
});

const LabelTypography = styled(Typography)({
    color: '#64747A',
    fontSize: 14,
    fontWeight: '400',
});

const ValueTypography = styled(Typography)({
    color: '#22292E',
    fontSize: 16,
    fontWeight: '600',
});

export default function Card({ title, category, status, policyNumber, effectiveDate, value }: CardProps) {
    return (
        <CardWrapper>
            <CardHeader spacing={0.5}>
                <Typography sx={{ color: '#00437A', fontSize: 20, fontWeight: '600' }}>{title}</Typography>
                <Stack direction="row" justifyContent="space-between" alignItems="flex-start">
                    <Typography sx={{ color: '#404B52', fontSize: 12, fontWeight: '400' }}>{category}</Typography>
                    <Typography sx={{ color: '#359485', fontSize: 16, fontWeight: '600' }}>{status}</Typography>
                </Stack>
            </CardHeader>
            <GradientDivider />
            <InfoSection direction="row" justifyContent="space-between" alignItems="center">
                <Stack><LabelTypography>Apólice</LabelTypography><ValueTypography>{policyNumber}</ValueTypography></Stack>
                <Stack><LabelTypography>Vigência</LabelTypography><ValueTypography>{effectiveDate}</ValueTypography></Stack>
            </InfoSection>
            <ValueSection direction="row" justifyContent="center" alignItems="center">
                <Stack>
                    <LabelTypography>Valor</LabelTypography>
                    <ValueTypography sx={{ fontSize: 20 }}>{value}</ValueTypography>
                </Stack>
            </ValueSection>
            <DetailsLink direction="row" alignItems="center" spacing={1.25}>
                <Typography sx={{ color: '#005CA9', fontSize: 16, fontWeight: '600' }}>Mais detalhes</Typography>
                <ArrowIcon />
            </DetailsLink>
        </CardWrapper>
    )
}