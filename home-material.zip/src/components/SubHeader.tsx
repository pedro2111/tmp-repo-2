import React, { useState } from "react";
import { Stack, Typography, Button, TextField, InputAdornment, styled, ButtonProps } from "@mui/material";
import SearchIcon from '@mui/icons-material/Search';

const SubHeaderWrapper = styled(Stack)(({ theme }) => ({
    width: '100%',
    maxWidth: 1153,
    margin: '0 auto',
    padding: theme.spacing(0, 2), // Add some padding for smaller screens
    gap: theme.spacing(5),
    fontFamily: 'CAIXA Std, sans-serif',
}));

interface FilterButtonProps extends ButtonProps {
    active?: boolean;
}

const FilterButton = styled(Button, {
    shouldForwardProp: (prop) => prop !== 'active',
})<FilterButtonProps>(({ theme, active }) => ({
    borderRadius: 1000,
    textTransform: 'none',
    fontWeight: 600,
    fontSize: 14,
    ...(active ? {
        backgroundColor: '#005CA9',
        color: 'white',
        '&:hover': {
            backgroundColor: '#00437A',
        }
    } : {
        backgroundColor: 'white',
        color: '#22292E',
        border: '1px solid #22292E',
        '&:hover': {
            backgroundColor: '#f0f0f0',
        }
    })
}));

const SearchInput = styled(TextField)({
    width: 350,
    '& .MuiOutlinedInput-root': {
        borderRadius: 4,
        backgroundColor: 'white',
        fontFamily: 'CAIXA Std, sans-serif',
        fontSize: 16,
        '& fieldset': {
            borderColor: '#9EB2B8',
        },
        '&:hover fieldset': {
            borderColor: '#64747A',
        },
    },
});

export default function SubHeader() {
    const [activeFilter, setActiveFilter] = useState('Todos');
    const filters = ['Todos', 'Ativos', 'Pendentes', 'Inativos'];

    return (
        <SubHeaderWrapper>
            <Stack>
                <Typography variant="h2" sx={{ color: '#005CA9', fontSize: 40, fontWeight: '600', lineHeight: '56px' }}>
                    Meus Produtos
                </Typography>
                <Typography variant="h5" sx={{ color: '#22292E', fontSize: 20, fontWeight: '400', lineHeight: '30px' }}>
                    Visualize abaixo suas conquistas de forma simples e rápida.
                </Typography>
            </Stack>

            <Stack direction="row" justifyContent="space-between" alignItems="center">
                <Stack spacing={1}>
                    <Typography sx={{ color: '#404B52', fontSize: 16, fontWeight: '400' }}>
                        Selecione para filtrar o status:
                    </Typography>
                    <Stack direction="row" spacing={1}>
                        {filters.map((filter) => (
                            <FilterButton
                                key={filter}
                                active={activeFilter === filter}
                                onClick={() => setActiveFilter(filter)}
                            >
                                {filter}
                            </FilterButton>
                        ))}
                    </Stack>
                </Stack>

                <SearchInput
                    placeholder="Buscar meus produtos"
                    size="small"
                    InputProps={{
                        startAdornment: (
                            <InputAdornment position="start">
                                <SearchIcon sx={{ color: '#64747A' }} />
                            </InputAdornment>
                        ),
                    }}
                />
            </Stack>
        </SubHeaderWrapper>
    )
}