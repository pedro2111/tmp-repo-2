import React from "react";
import Chip from '@mui/material/Chip';
import Stack from '@mui/material/Stack';

import { BrowserRouter as Router, Routes, Route, Link } from "react-router-dom";
import Home from "./components/Home";

export default function App({ name }) {
  const handleClick = () => {
    console.info('You clicked the Chip.');
  };

  return (
    <Router>
      <div>
        {/* Container Principal */}
        <div>
          {/* MUI Chips */}
          <div>
            <Stack direction="row" spacing={1}>
              <Link to="/cvp"><Chip label="MFE CVP" onClick={handleClick} /></Link>
              <Chip label="Clickable" onClick={handleClick} />
            </Stack>
          </div>

          {/* Navigation em Linha */}
          <nav>
            <ul>
              <li>
                <Link to="/home">
                  Home
                </Link>
              </li>
              <li>
                <Link to="/react/about">
                  About
                </Link>
              </li>
              <li>
                <Link to="/react/users">
                  Users
                </Link>
              </li>
            </ul>
          </nav>

          {/* Conteúdo das Rotas */}
          <div>
            <Routes>
              <Route path="/react/about" element={<About />} />
              <Route path="/react/users" element={<Users />} />
              <Route path="/home" element={<Home />} />
            </Routes>
          </div>
        </div>
      </div>
    </Router>
  );
}


function About() {
  return <h2>About</h2>;
}

function Users() {
  return <h2>Users</h2>;
}
