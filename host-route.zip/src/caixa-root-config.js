import { registerApplication, start } from "single-spa";

registerApplication({
  name: "@cvp/mfe-cvp",
  app: () =>
    System.import(
      /* webpackIgnore: true */ // @ts-ignore-next
      "@cvp/mfe-cvp"
    ),
  activeWhen: (location) => location.pathname === "/cvp"
});
registerApplication({
  name: "@caixa/mfe-navbar",
  app: () =>
    import(
      /* webpackIgnore: true */ // @ts-ignore-next
      "@caixa/mfe-navbar" 
    ),
  activeWhen: ["/"]
});
registerApplication({
  name: "@single-spa/welcome",
  app: () =>
    import(
      /* webpackIgnore: true */ // @ts-ignore-next
      "@single-spa/welcome"
    ),
  activeWhen: (location) => location.pathname === "/welcome",
});

// registerApplication({
//   name: "@caixa/navbar",
//   app: () =>
//     import(
//       /* webpackIgnore: true */ // @ts-ignore-next
//       "@caixa/navbar"
//     ),
//   activeWhen: ["/"],
// });

start({
  urlRerouteOnly: true,
});
