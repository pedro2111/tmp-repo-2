# Documento Técnico de Integração: Web Component SeguridadeCard

**Autor:** Manus AI
**Data:** 21 de Janeiro de 2026
**Versão:** 1.0

## 1. Introdução

Este documento técnico detalha a arquitetura, o funcionamento e os métodos de integração do **Web Component `seguridade-card`**, desenvolvido utilizando a biblioteca **Lit** [1]. O objetivo principal deste componente é fornecer uma solução de *card* de seguridade reutilizável e agnóstica a *frameworks*, ideal para ser consumida em ambientes de *microfrontends* baseados em tecnologias como React e Angular.

A natureza de *Web Component* garante que o *markup* e o estilo do card sejam encapsulados dentro de um *Shadow DOM*, prevenindo conflitos de CSS com o ambiente hospedeiro e assegurando a consistência visual em diferentes aplicações [2].

## 2. Visão Geral do Componente

O `seguridade-card` é um elemento HTML customizado (`<seguridade-card>`) que aceita dados via atributos (propriedades) e interage com o ambiente hospedeiro através de eventos customizados.

### 2.1. Propriedades (Atributos)

As propriedades do componente são definidas como atributos HTML e controlam o conteúdo e a aparência do card.

| Propriedade | Tipo | Descrição | Valores de Exemplo |
| :--- | :--- | :--- | :--- |
| `title` | String | Título principal do produto (ex: "Vida Mulher"). | `"Vida Mulher"` |
| `product` | String | Categoria do produto (ex: "Vida"). | `"Vida"` |
| `status` | String | Estado do produto, que define a cor da barra de status. | `"vigente"`, `"pendente"`, `"inativo"` |
| `policy` | String | Número da apólice. | `"12134465"` |
| `validity` | String | Data de vigência. | `"22/02/2024"` |
| `value` | String | Valor formatado do produto (ex: "R$ 12.300,00"). | `"R$ 12.300,00"` |
| `details-label` | String | Texto do link de detalhes. | `"Mais Detalhes"` |

### 2.2. Eventos Customizados

O componente emite eventos nativos do DOM que podem ser capturados pelo *framework* hospedeiro.

| Evento | Descrição | Detalhes do Evento (`e.detail`) |
| :--- | :--- | :--- |
| `details-click` | Disparado ao clicar no link "Mais Detalhes". | `{ policy: string }` - O número da apólice. |
| `toggle-visibility` | Disparado ao clicar no ícone de olho para mostrar/esconder o valor. | `{ showValue: boolean }` - O novo estado de visibilidade. |

## 3. Métodos de Integração

A integração do `seguridade-card` é realizada em duas etapas: a importação do *script* e a utilização do elemento customizado.

### 3.1. Integração em HTML Puro (Vanilla JS)

Este é o método mais direto, ideal para testes ou ambientes que não utilizam *frameworks*.

#### 3.1.1. Importação

O componente deve ser importado como um módulo JavaScript no `<head>` ou antes do fechamento do `</body>`.

```html
<!-- Importação do script do Web Component -->
<script type="module" src="./dist/seguridade-card.es.js"></script>
```

#### 3.1.2. Utilização e Captura de Eventos

O componente é usado como uma tag HTML normal. A captura de eventos é feita via `addEventListener`.

```html
<seguridade-card
    title="Vida Mulher"
    product="Vida"
    status="vigente"
    policy="12134465"
    validity="22/02/2024"
    value="R$ 12.300,00">
</seguridade-card>

<script>
    document.querySelector('seguridade-card').addEventListener('details-click', (e) => {
        console.log('Apólice clicada:', e.detail.policy);
        // Lógica de navegação ou exibição de modal
    });
</script>
```

### 3.2. Integração em React

A integração em React requer atenção especial à passagem de propriedades e à captura de eventos customizados, devido à forma como o React lida com o DOM sintético.

#### 3.2.1. Importação

A importação do *script* deve ser feita no ponto de entrada da aplicação (ex: `index.js` ou `main.jsx`) para garantir que o elemento customizado seja registrado antes de ser renderizado.

```javascript
// index.js ou main.jsx
import 'caminho/para/dist/seguridade-card.es.js';
// ... restante do código React
```

#### 3.2.2. Utilização e Boas Práticas

**Boas Práticas:**

1.  **Passagem de Dados via Atributos:** O React passa propriedades para componentes nativos como atributos HTML. Para o `seguridade-card`, utilize atributos *camelCase* ou *kebab-case* conforme a definição do componente Lit.
2.  **Captura de Eventos via `useRef`:** O React não reconhece nativamente eventos customizados de *Web Components* no seu sistema de eventos sintéticos. A melhor prática é usar o *hook* `useRef` para acessar o elemento DOM real e anexar *listeners* de eventos nativos [3].

```jsx
import React, { useEffect, useRef } from 'react';

// Certifique-se de que o script foi importado no ponto de entrada da aplicação

const SeguridadeCardWrapper = ({ data }) => {
  const cardRef = useRef(null);

  useEffect(() => {
    const card = cardRef.current;
    
    // 1. Função de tratamento de evento
    const handleDetails = (e) => {
      console.log('Detalhes da apólice (React):', e.detail.policy);
      // Exemplo: Chamar uma função global ou de contexto do React
    };
    
    // 2. Anexar o listener ao elemento DOM real
    card.addEventListener('details-click', handleDetails);
    
    // 3. Limpeza do listener (importante para evitar vazamento de memória)
    return () => {
      card.removeEventListener('details-click', handleDetails);
    };
  }, []); // Executa apenas na montagem e desmontagem

  return (
    <seguridade-card
      ref={cardRef}
      title={data.title}
      product={data.product}
      status={data.status}
      policy={data.policy}
      validity={data.validity}
      value={data.value}
    ></seguridade-card>
  );
};

export default SeguridadeCardWrapper;
```

### 3.3. Integração em Angular

A integração em Angular é mais simplificada, mas requer uma configuração inicial para que o compilador do Angular reconheça as tags customizadas.

#### 3.3.1. Configuração do Módulo

Para que o Angular não gere erros ao encontrar a tag `<seguridade-card>`, é necessário adicionar o `CUSTOM_ELEMENTS_SCHEMA` ao módulo onde o componente será utilizado (ex: `app.module.ts` ou no `@Component` se for *standalone*).

```typescript
// app.module.ts
import { CUSTOM_ELEMENTS_SCHEMA, NgModule } from '@angular/core';
// ...

@NgModule({
  // ...
  schemas: [CUSTOM_ELEMENTS_SCHEMA], // Permite o uso de tags customizadas
  // ...
})
export class AppModule { }
```

#### 3.3.2. Importação

A importação do *script* deve ser feita no `main.ts` para que o elemento customizado seja registrado no DOM antes do *bootstrap* da aplicação.

```typescript
// main.ts
import './caminho/para/dist/seguridade-card.es.js';
// ... restante do código Angular
```

#### 3.3.3. Utilização e Boas Práticas

**Boas Práticas:**

1.  **Passagem de Dados via *Attribute Binding*:** Para garantir que o Angular trate as propriedades do Web Component como atributos HTML, utilize a sintaxe `[attr.propriedade]`. Isso é crucial para propriedades que não são *booleanas* ou que não são reconhecidas pelo Angular como *inputs* de componentes nativos.
2.  **Captura de Eventos via *Event Binding*:** O Angular suporta nativamente a captura de eventos customizados do DOM. Utilize a sintaxe `(evento-customizado)` para mapear o evento a um método do seu componente Angular.

```typescript
// app.component.ts
import { Component } from '@angular/core';

@Component({
  selector: 'app-root',
  template: `
    <seguridade-card
      [attr.title]="'Vida Mulher'"
      [attr.product]="'Vida'"
      [attr.status]="'pendente'"
      [attr.policy]="apoliceId"
      [attr.validity]="'22/02/2024'"
      [attr.value]="'R$ 12.300,00'"
      (details-click)="onDetailsClick($event)"
    ></seguridade-card>
  `,
})
export class AppComponent {
  apoliceId = '12134465';

  onDetailsClick(event: CustomEvent) {
    console.log('Detalhes da apólice (Angular):', event.detail.policy);
    // Lógica de serviço ou navegação do Angular
  }
}
```

## 4. Conclusão

O `seguridade-card` oferece uma solução robusta e isolada para a exibição de informações de seguridade. Sua arquitetura baseada em Lit e *Web Components* o torna um ativo valioso para a construção de *microfrontends*, garantindo **reutilização**, **isolamento de estilos** e **interoperabilidade** entre diferentes *frameworks* de front-end [4].

---

## Referências

[1] Lit. *Fast, lightweight Web Components*. [Online]. Available: https://lit.dev/
[2] MDN Web Docs. *Using shadow DOM*. [Online]. Available: https://developer.mozilla.org/en-US/docs/Web/Web_Components/Using_shadow_DOM
[3] React Documentation. *Web Components*. [Online]. Available: https://react.dev/learn/faq-structure#how-do-i-use-web-components
[4] Micro Frontends. *Micro Frontends*. [Online]. Available: https://micro-frontends.org/
