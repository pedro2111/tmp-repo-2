import { LitElement, html, css } from 'lit';

export class SeguridadeCard extends LitElement {
  static properties = {
    title: { type: String },
    product: { type: String },
    status: { type: String }, // 'vigente', 'pendente', 'inativo'
    policy: { type: String },
    validity: { type: String },
    value: { type: String },
    showValue: { type: Boolean },
    detailsLabel: { type: String }
  };

  static styles = css`
    :host {
      display: inline-block;
      font-family: "CAIXA Std", Arial, Helvetica, sans-serif;
      --dsc-typography-text-standard-600: 600 1rem "CAIXA Std", Arial, Helvetica, sans-serif;
      --dsc-typography-text-big-600: 600 1.25rem "CAIXA Std", Arial, Helvetica, sans-serif;
      --dsc-typography-text-small-400: 400 0.875rem "CAIXA Std", Arial, Helvetica, sans-serif;
      --dsc-typography-text-standard-400: 400 1rem "CAIXA Std", Arial, Helvetica, sans-serif;
      --dsc-border-radius-small: 8px;
      --dsc-border-radius-big: 24px;
      --dsc-border-width-hairline: 1px solid #EBF1F2;
      --dsc-color-bg-highlight-5: #005CA9;
      --dsc-color-bg-highlight-6: #00437a;
      --dsc-color-gradient-oceano: #54BBAB;
      --dsc-color-gradient-gelo: #D0E0E3;
      --grayscale-30: #eBf1f2;
      --grayscale-90: #64747a;
      --grayscale-110: #404b52;
      --grayscale-130: #22292e;
      --secondary-90: #d87b00;
      --tertiary-90: #359485;
    }

    .card {
      width: 362px;
      height: 280px;
      background-color: #fff;
      border-radius: var(--dsc-border-radius-small);
      border: var(--dsc-border-width-hairline);
      box-shadow: 4px 4px 8px 0px #8C8A8A40;
      display: flex;
      flex-direction: column;
      align-items: center;
      gap: 12px;
      position: relative;
      overflow: hidden;
      box-sizing: border-box;
    }

    .card::before {
      content: "";
      transform: rotate(45deg);
      height: 29px;
      width: 134px;
      top: 262px;
      left: -30px;
      background-color: var(--dsc-color-gradient-gelo);
      position: absolute;
    }

    .card::after {
      content: "";
      transform: rotate(45deg);
      height: 29px;
      width: 134px;
      top: 278px;
      left: -40px;
      background-color: var(--dsc-color-bg-highlight-5);
      position: absolute;
    }

    .header {
      margin-top: 24px;
      width: 311px;
      height: 44px;
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .header--title {
      color: var(--dsc-color-bg-highlight-6);
      font: var(--dsc-typography-text-big-600);
    }

    .header--title.inativo {
      color: var(--grayscale-90);
    }

    .header--subtitle {
      display: flex;
      justify-content: space-between;
      font: var(--dsc-typography-text-standard-600);
    }

    .header--produto {
      color: var(--grayscale-110);
      font: var(--dsc-typography-text-standard-400);
    }

    .header--produto.inativo {
      color: var(--grayscale-90);
    }

    .header--status {
      font: var(--dsc-typography-text-standard-600);
      text-transform: uppercase;
    }

    .header--status.vigente {
      color: var(--tertiary-90);
    }

    .header--status.pendente {
      color: var(--secondary-90);
    }

    .header--status.inativo {
      color: var(--grayscale-90);
    }

    .hr {
      width: 311px;
      height: 3px;
      border-radius: var(--dsc-border-radius-big);
    }

    .hr--vigente {
      background: linear-gradient(90deg, var(--dsc-color-bg-highlight-5) 0%, var(--dsc-color-gradient-oceano) 61%, #FFFFFF 100%);
    }

    .hr--pendente {
      background: linear-gradient(90deg, var(--dsc-color-bg-highlight-5) 0%, var(--secondary-90) 66%, #FFFFFF 100%);
    }

    .hr--inativo {
      background: linear-gradient(90deg, var(--grayscale-90) 0%, var(--dsc-color-gradient-gelo) 72.5%, #FFFFFF 100%);
    }

    .info {
      display: flex;
      justify-content: space-between;
      width: 313px;
      font: var(--dsc-typography-text-standard-600);
    }

    .apolice, .vigencia {
      display: flex;
      flex-direction: column;
      gap: 4px;
    }

    .apolice--title, .vigencia--title {
      font: var(--dsc-typography-text-small-400);
      color: var(--grayscale-90);
    }

    .apolice--value {
      color: var(--grayscale-130);
    }

    .apolice--value.inativo {
      color: var(--grayscale-90);
    }

    .valor {
      display: flex;
      flex-direction: column;
      width: 313px;
      border-width: 1px 0px 1px 0px;
      border-style: solid;
      border-color: var(--grayscale-30);
      padding: 10px 0px;
      align-items: center;
    }

    .valor--title {
      font: var(--dsc-typography-text-small-400);
      color: var(--grayscale-90);
      width: 169px;
    }

    .valor--value {
      display: flex;
      gap: 8px;
      width: 169px;
      align-items: center;
    }

    .valor--value--data {
      color: var(--grayscale-130);
      font: var(--dsc-typography-text-big-600);
    }

    .valor--value--data.inativo {
      color: var(--grayscale-90);
    }

    .valor--value--icon {
      width: 22px;
      height: 22px;
      display: flex;
      justify-content: center;
      align-items: center;
      color: var(--grayscale-110);
      cursor: pointer;
    }

    .valor--value--icon.inativo {
      color: var(--grayscale-90);
    }

    .footer {
      width: 313px;
      padding-top: 8px;
      display: flex;
      justify-content: flex-end;
      align-items: center;
      cursor: pointer;
    }

    .footer--link {
      font: var(--dsc-typography-text-standard-600);
      color: var(--dsc-color-bg-highlight-5);
      margin-right: 8px;
    }

    svg {
      display: block;
    }
  `;

  constructor() {
    super();
    this.title = '';
    this.product = '';
    this.status = 'vigente';
    this.policy = '';
    this.validity = '';
    this.value = '';
    this.showValue = true;
    this.detailsLabel = 'Mais Detalhes';
  }

  toggleValue() {
    this.showValue = !this.showValue;
    this.dispatchEvent(new CustomEvent('toggle-visibility', {
      detail: { showValue: this.showValue },
      bubbles: true,
      composed: true
    }));
  }

  handleDetails() {
    this.dispatchEvent(new CustomEvent('details-click', {
      detail: { policy: this.policy },
      bubbles: true,
      composed: true
    }));
  }

  render() {
    const isInactive = this.status === 'inativo';
    
    return html`
      <article class="card">
        <div class="header">
          <div class="header--title ${isInactive ? 'inativo' : ''}">${this.title}</div>
          <div class="header--subtitle">
            <span class="header--produto ${isInactive ? 'inativo' : ''}">${this.product}</span>
            <span class="header--status ${this.status}">${this.status}</span>
          </div>
        </div>
        <div class="hr hr--${this.status}"></div>
        <div class="info">
          <div class="apolice">
            <span class="apolice--title">Apólice</span>
            <span class="apolice--value ${isInactive ? 'inativo' : ''}">${this.policy}</span>
          </div>
          <div class="vigencia">
            <span class="vigencia--title">Vigência</span>
            <span class="apolice--value ${isInactive ? 'inativo' : ''}">${this.validity}</span>
          </div>
        </div>
        <div class="valor">
          <span class="valor--title">Valor</span>
          <div class="valor--value">
            <span class="valor--value--data ${isInactive ? 'inativo' : ''}">
              ${this.showValue ? this.value : 'R$ ••••••••'}
            </span>
            <span class="valor--value--icon ${isInactive ? 'inativo' : ''}" @click="${this.toggleValue}">
              ${this.showValue ? html`
                <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M11 3.55C14.79 3.55 18.17 5.68 19.82 9.05C19.23 10.27 18.4 11.32 17.41 12.17L18.82 13.58C20.21 12.35 21.31 10.81 22 9.05C20.27 4.66 16 1.55 11 1.55C9.73 1.55 8.51 1.75 7.36 2.12L9.01 3.77C9.66 3.64 10.32 3.55 11 3.55ZM9.93 4.69L12 6.76C12.57 7.01 13.03 7.47 13.28 8.04L15.35 10.11C15.43 9.77 15.49 9.41 15.49 9.04C15.5 6.56 13.48 4.55 11 4.55C10.63 4.55 10.28 4.6 9.93 4.69ZM1.01 1.42L3.69 4.1C2.06 5.38 0.77 7.08 0 9.05C1.73 13.44 6 16.55 11 16.55C12.52 16.55 13.98 16.26 15.32 15.73L18.74 19.15L20.15 17.74L2.42 0L1.01 1.42ZM8.51 8.92L11.12 11.53C11.08 11.54 11.04 11.55 11 11.55C9.62 11.55 8.5 10.43 8.5 9.05C8.5 9 8.51 8.97 8.51 8.92ZM5.11 5.52L6.86 7.27C6.63 7.82 6.5 8.42 6.5 9.05C6.5 11.53 8.52 13.55 11 13.55C11.63 13.55 12.23 13.42 12.77 13.19L13.75 14.17C12.87 14.41 11.95 14.55 11 14.55C7.21 14.55 3.83 12.42 2.18 9.05C2.88 7.62 3.9 6.44 5.11 5.52Z" fill="currentColor"/>
                </svg>
              ` : html`
                <svg width="22" height="20" viewBox="0 0 22 20" fill="none" xmlns="http://www.w3.org/2000/svg">
                  <path d="M11 4.5C7.13 4.5 3.87 6.63 2.22 10C3.87 13.37 7.13 15.5 11 15.5C14.87 15.5 18.13 13.37 19.78 10C18.13 6.63 14.87 4.5 11 4.5ZM11 13.5C9.07 13.5 7.5 11.93 7.5 10C7.5 8.07 9.07 6.5 11 6.5C12.93 6.5 14.5 8.07 14.5 10C14.5 11.93 12.93 13.5 11 13.5ZM11 8C9.9 8 9 8.9 9 10C9 11.1 9.9 12 11 12C12.1 12 13 11.1 13 10C13 8.9 12.1 8 11 8Z" fill="currentColor"/>
                </svg>
              `}
            </span>
          </div>
        </div>
        <div class="footer" @click="${this.handleDetails}">
          <span class="footer--link">${this.detailsLabel}</span>
          <span class="footer--icon">
            <svg width="24" height="24" viewBox="0 0 24 24" fill="none" xmlns="http://www.w3.org/2000/svg">
              <path d="M9 18L15 12L9 6" stroke="#005CA9" stroke-width="2.5" stroke-linecap="round" stroke-linejoin="round"/>
            </svg> 
          </span>
        </div>
      </article>
    `;
  }
}

customElements.define('seguridade-card', SeguridadeCard);
