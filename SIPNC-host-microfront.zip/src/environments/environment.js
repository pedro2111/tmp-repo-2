//Desenvolvedor: EDITAR ESTE ARQUIVO APENAS caso você esteja desenvolvendo MFEs.
//O seu MFE deve ser adicionado na variável "listaMFEs" abaixo.
//NÃO é necessário editar a variável "variaveisAmbiente".
//Após editar este arquivo, é necessário que o comando npm start seja executado novamente,
//pois a atualização automática de alterações NÃO funciona para este caso.
const listaMFEs = `[
  {
    "application":"design-system",
    "route":"/design-system",
    "path":"//localhost:4299/main.js"
  },
  {
    "application":"mfe-api",
    "route":"/funcionalidades",
    "path":"//localhost:5099/main.js"
  }
]`;

const variaveisAmbiente = {
  urlCDN: "http://localhost:9000",
  urlHost: "//localhost:9000/caixa-sipnc-host.js",
  urlCore: "http://localhost:9000/static/core/caixa-sipnc-core.js",
  urlNavBar: "http://localhost:9000/static/navbar/main-es5.js",
  urlMenuDinamico: "http://localhost:9000",
  listaMFEs: listaMFEs,
  isBuscarMFEsDinamicos: "false",
  token: "eyJhbGciOiJSUzI1NiIsInR5cCIgOiAiSldUIiwia2lkIiA6ICJNRmVKNjVfRC14cU55M1Zta01Ib01WS1NjZlA3S21ZazdtVjBJaEsta0F3In0.eyJqdGkiOiI1MmFkNjk4Yi1kYWU4LTRiNzAtOWUzMi1iZjZiMjBhZDBmOGEiLCJleHAiOjE3MTE2ODQwMjMsIm5iZiI6MCwiaWF0IjoxNzExNjgzMTIzLCJpc3MiOiJodHRwczovL2xvZ2luLmRlcy5jYWl4YS9hdXRoL3JlYWxtcy9pbnRyYW5ldCIsInN1YiI6ImU2ZGYyZmM2LWE5MGUtNGIwZC04ZDY3LTA1YzBmMDViNjVjOCIsInR5cCI6IkJlYXJlciIsImF6cCI6ImNsaS13ZWItcG5jIiwibm9uY2UiOiI4NDU0ZjQ0My1mMTYzLTRiZDUtODVmOC05NGMzZmQ5MjY5MzciLCJhdXRoX3RpbWUiOjE3MTE2ODMxMjIsInNlc3Npb25fc3RhdGUiOiI1MmM2ZmUzMC01N2NjLTQ0MmItYjI4MC00OTYyMzE4NDU3NzYiLCJhY3IiOiIxIiwiYWxsb3dlZC1vcmlnaW5zIjpbIioiXSwicmVhbG1fYWNjZXNzIjp7InJvbGVzIjpbIklGWDAxMCIsIk1GRV9STUNfQ0FQVEFDQU8iLCJQTkNDRE8iLCJQTkNBUFgiLCJQTkNBQUMiLCJQTkNMT0ciLCJQTkNDRUMiLCJQQlNfSU5ESUNBX0NPTlRBIiwiUE5DQUlDIiwiQlJKX1NGR19JTkZPUk1BQ09FU19GR1RTX0FQSSIsInVtYV9hdXRob3JpemF0aW9uIiwiQlJKX1NGR19TQVFVRV9FTUVSR0VOQ0lBTF9BUEkiLCJQTkNDQ1MiLCJQTkNDQ1QiLCJQTkNDQ1IiLCJQTkNDQ08iLCJQTkNDVEEiLCJDSURfQ09OU1VMVEFfQ0FSVEFPX0FQSSIsIkNJRF9FTUlURV9DQVJUQU9fQVBJIiwiUE5DQ0NIIiwiUE5DQ0REIiwiUE5DQ0xNIiwiUE5DQVBTIiwiUE5DQ0RFIiwiUE5DQ1RSIiwiUE5DQ0RBIiwiUE5DQVBJIiwiUE5DQVBEIiwiTUZFX1JNQ1BWUyIsIlBOQ0NTQyIsIlNBR09QMSIsIlBOQ0NTRCIsIk1GRV9STUNQVlQiLCJQTkNDU0EiLCJNRkVfUk1DUFZWIiwiTUZFX1JNQ1BWTCIsIk1GRV9IT0pTRU4iLCJTQUdPUDYiLCJNRkVfUk1DUFZPIiwiTUZFX1JNQ1BWUCIsIlNBR09QMyIsIlBOQ0NCRSIsIk1GRV9STUNQVlIiLCJNRkVfUk1DUFZDIiwiUE5DQ0NDIiwiTUZFX1JNQ1BWRCIsIlBOQ0NDRCIsIlBOQ0NDQSIsIk1GRV9STUNQVkYiLCJNRkVfSE9KVkNRIiwiTUZFX0hPSlZDUCIsIlBOQ0NTTSIsIk1GRV9STUNQVkkiLCJQTkNBR0MiLCJGRUMwMTAwIiwiQ0lEX0NBTkNFTEFfQ0FSVEFPX0FQSSIsIlBESTAwMyIsIlBOQ0NTRSIsIlBESTAwMSIsIk1UUlNETklOVCIsIlBOQ0NSQyIsIlBOQ0NJViIsIlBOQ1BDQSIsIk1UUkRPU09QRSIsIlBOQ0NJUiIsIlBOQ0NJUCIsIlBOQ0NJTiIsIlBOQ0NBQyIsIlBOQ0FGRyIsIlBOQ1JPVCIsIlBOQ0NBUyIsIlBOQ0NSRSIsIlBOQ0FOQyIsIlNBR1NVUiIsIk1GRV9STUNfMzYwIiwiTUZFX1JNQ1BQVCIsIlBOQ0NQWCIsIlBOQ0FMVCIsIk1GRV9IT0pWSVAiLCJQTkNBTFAiLCJNRkVfSE9KVkFDIiwiUE5DQ1BTIiwiU0FHU1VBIiwiRk1QMDExIiwiQlJKX1NGR19TQVFVRV9ESUdJVEFMX0FQSSIsIlBOQ0NJQyIsIlBOQ0NJQSIsIk1GRV9STUNWQ0MiLCJHUEZVTkQiLCJQTkNBQ1MiLCJQTkNBQ1QiLCJNRkVfUk1DSUlQIiwiUE5DQUNSIiwiUE5DQUNPIiwiUE5DQVRBIiwiUE5DQUNJIiwiR01TX0VOVklBX01FTlNBR0VNIiwiUE5DQUNIIiwiU0FHQVMxIiwiUE5DQURBIiwiUE5DQ1BJIiwiUE5DQVNFIiwiUE5DQVNDIiwiUE5DQVNEIiwiUE5DQVNTIiwiUE5DQUNDIiwiUE5DQUNEIiwiUE5DQ0dGIiwiUE5DQ09OIiwiUE5DQUNBIiwiUE5DQ0dBIiwib2ZmbGluZV9hY2Nlc3MiLCJQTkNBU00iLCJTQUdHU1IiLCJQTkNBQVMiLCJHRUM0MDMiLCJQTkNBUkUiLCJHRUM0MDEiLCJNRkVfUk1DUElJIiwiR0VDNDA3IiwiR0VDNDA2IiwiUE5DQUlWIiwiTUZFX1JNQ19OUFMiLCJQTkNDRVAiLCJHRUM0MDUiLCJNRkVfSE9KQ1NOIiwiUE5DQUFMIiwiU0FHR0UzIiwiU0FHR0UxIiwiUE5DQUlQIiwiUE5DQUFFIiwiUE5DQUlOIiwiUE5DQ0ZHIiwiU0FHTkFQIiwiUE5DQ05GIiwiUE5DQUFVIiwiTUZFX0hPSkdTVCJdfSwic2NvcGUiOiJvcGVuaWQiLCJzZWdtZW50b19zaXN0ZW1hIjoiMjA3NiIsIjJmX2NlcnQiOiJmYWxzZSIsImNvLXVuaWRhZGUiOiIwMDAyIiwiY2VydF9vYnIiOmZhbHNlLCJuYW1lIjoiVVNFUiBDMTQzMzY5IENFU09BIFNJUEFOIiwicHJlZmVycmVkX3VzZXJuYW1lIjoiYzg5Nzk5OCIsImdpdmVuX25hbWUiOiJVU0VSIEMxNDMzNjkgQ0VTT0EiLCJjbGllbnRBZGRyZXNzIjoiMTAuMTkzLjIyNC40IiwiZmFtaWx5X25hbWUiOiJTSVBBTiIsImVtYWlsIjoiYzg5Nzk5OEBtYWlsLmNhaXhhIn0.uRKqGoxNXhGWIEqz4BxRvyjUGtjpgj_8WdLYiLQMd3HUQmnwnjNtRmKwdbalgat0PnnIpbL-_jONB_yCqLgZHzzraYPlcylvQLRwPuXagnuwjxWSgvjhviwomf6t_o12PMZlRZl6n07GIzTj3Hg2e10j8rR8MBTn6lrkfnfBTUjnibCJksVSBS9Y1m7zS1UdxHdNQ-qJRguMGH3Dzq7XrGG6fM1CBMWYbYwFGzXl8VIsJaZ59by2pfJrAUOZYNLy53Opek1m_zLVD1l3SpafZvcQbEfXpU10SJAP_acvTg6Yv0rRQiZv8_VUMJJdlpHBeyggW2pWjbqGfe1G4kvkqA",
  tokenParsed: JSON.stringify({ "jti": "d8811171-7979-4fdf-8bca-3478fb4541ce", "exp": 1699050831, "nbf": 0, "iat": 1699049931, "iss": "https://login.des.caixa/auth/realms/intranet", "sub": "e6df2fc6-a90e-4b0d-8d67-05c0f05b65c8", "typ": "Bearer", "azp": "cli-web-pnc", "nonce": "6ae2ebae-d68d-45ac-a78a-cdfd0faf609c", "auth_time": 1699049931, "session_state": "0539e529-a6ef-4951-9757-bb8da3e81f46", "acr": "1", "allowed-origins": ["*"], "realm_access": { "roles": ["IFX010", "MFE_RMC_CAPTACAO", "PNCCDO", "PNCAPX", "PNCAAC", "PNCLOG", "PNCCEC", "PNCAIC", "BRJ_SFG_INFORMACOES_FGTS_API", "uma_authorization", "BRJ_SFG_SAQUE_EMERGENCIAL_API", "PNCCCS", "PNCCCT", "PNCCCR", "PNCCCO", "PNCCTA", "CID_CONSULTA_CARTAO_API", "CID_EMITE_CARTAO_API", "PNCCCH", "PNCCDD", "PNCCLM", "PNCAPS", "PNCCDE", "PNCCTR", "PNCCDA", "PNCAPI", "PNCAPD", "MFE_RMCPVS", "PNCCSC", "PNCCSD", "MFE_RMCPVT", "PNCCSA", "MFE_RMCPVV", "MFE_RMCPVL", "MFE_HOJSEN", "MFE_RMCPVO", "MFE_RMCPVP", "PNCCBE", "MFE_RMCPVR", "MFE_RMCPVC", "PNCCCC", "MFE_RMCPVD", "PNCCCD", "PNCCCA", "MFE_RMCPVF", "MFE_HOJVCQ", "MFE_HOJVCP", "PNCCSM", "MFE_RMCPVI", "PNCAGC", "FEC0100", "CID_CANCELA_CARTAO_API", "PDI003", "PNCCSE", "PDI001", "MTRSDNINT", "PNCCRC", "PNCCIV", "PNCPCA", "MTRDOSOPE", "PNCCIR", "PNCCIP", "PNCCIN", "PNCCAC", "PNCAFG", "PNCROT", "PNCCAS", "PNCCRE", "PNCANC", "MFE_RMC_360", "MFE_RMCPPT", "PNCCPX", "PNCALT", "MFE_HOJVIP", "PNCALP", "MFE_HOJVAC", "PNCCPS", "FMP011", "BRJ_SFG_SAQUE_DIGITAL_API", "PNCCIC", "PNCCIA", "MFE_RMCVCC", "PNCACS", "PNCACT", "MFE_RMCIIP", "PNCACR", "PNCACO", "PNCATA", "PNCACI", "GMS_ENVIA_MENSAGEM", "PNCACH", "PNCADA", "PNCCPI", "PNCASE", "PNCASC", "PNCASD", "PNCASS", "PNCACC", "PNCACD", "PNCCGF", "PNCCON", "PNCACA", "PNCCGA", "offline_access", "PNCASM", "PNCAAS", "GEC403", "PNCARE", "GEC401", "MFE_RMCPII", "GEC407", "GEC406", "PNCAIV", "MFE_RMC_NPS", "PNCCEP", "GEC405", "MFE_HOJCSN", "PNCAAL", "PNCAIP", "PNCAAE", "PNCAIN", "PNCCFG", "PNCCNF", "PNCAAU", "MFE_HOJGST"] }, "scope": "openid", "2f_cert": "false", "co-unidade": "0002", "cert_obr": false, "name": "Usuario Teste SIPAN Teste SIPAN", "preferred_username": "c897998", "given_name": "Usuario Teste SIPAN", "clientAddress": "10.193.160.91", "family_name": "Teste SIPAN", "email": "c897998@mail.caixa" }),
  // cpfCnpj: "06102400992",
  cpfCnpj: "06102400992",

};
module.exports = variaveisAmbiente;

/*Legenda:
  urlCDN: endereço do CDN;
  urlHost: endereço do host;
  urlCore: endereço do core; //Editar esta variável quando estiver modificando o core: //localhost:4000;
  urlNavBar: endereço do navbar; //Editar esta variável quando estiver modificando o navbar: //localhost:4201;
  urlMenuDinamico: endereço do backend do menu dinâmico;
  listaMFEs: lista de MFEs a serem carregados pelo host;
  isBuscarMFEsDinamicos: flag que indica se a lista de MFEs a serem carregados virá da variável "listaMFEs" ou
                         do backend do menu dinâmico;
*/
