//Desenvolvedor: NÃO EDITAR ESTE ARQUIVO caso você esteja desenvolvendo MFEs
//Este arquivo deve ser editado somente caso o host esteja sendo alterado.
const listaMFEs = `[]`;
const variaveisAmbiente = {
  urlCDN: "__SIPNC_CDN_PATH__",
  urlHost: "__SIPNC_HOST_URL__",
  urlCore: "__SIPNC_CORE_URL__",
  urlNavBar: "__SIPNC_NAVBAR_URL__",
  urlMenuDinamico: "__SIPNC_MENU_DINAMICO_PATH__",
  listaMFEs: listaMFEs,
  isBuscarMFEsDinamicos: "true",
};
module.exports = variaveisAmbiente;

/*
  urlCDN: endereço do CDN;
  urlHost: endereço do host;
  urlCore: endereço do core;
  urlNavBar: endereço do navbar;
  urlMenuDinamico: endereço do backend do menu dinâmico;
  listaMFEs: lista de MFEs a serem carregados pelo host;
  isBuscarMFEsDinamicos: flag que indica se a lista de MFEs a serem carregados virá da variável "listaMFEs" ou
                         do backend do menu dinâmico;
*/
