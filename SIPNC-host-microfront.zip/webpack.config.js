const { merge } = require("webpack-merge");
const singleSpaDefaults = require("webpack-config-single-spa-ts");
const HtmlWebpackPlugin = require("html-webpack-plugin");
const path = require("path");
const { webpack } = require("webpack");
const Dotenv = require("dotenv-webpack");
const varAmbienteDev = require("./src/environments/environment.js");
const varAmbienteProd = require("./src/environments/environment.prod.js");
const CopyWebpackPlugin = require('copy-webpack-plugin');

module.exports = (webpackConfigEnv, argv) => {
  const orgName = "caixa";
  const defaultConfig = singleSpaDefaults({
    orgName,
    projectName: "sipnc-host",
    webpackConfigEnv,
    argv,
    disableHtmlGeneration: true,
  });
  let varEnvPath;
  let varAmbiente;
  if (webpackConfigEnv.isLocal) {
    varEnvPath = "src/environments/environment.env";
    varAmbiente = varAmbienteDev;
  } else {
    varEnvPath = "src/environments/environment.prod.env";
    varAmbiente = varAmbienteProd;
  }
  return merge(defaultConfig, {
    plugins: [
      new Dotenv({
        path: varEnvPath,
      }),
      new HtmlWebpackPlugin({
        inject: false,
        template: "src/index.ejs",
        publicPath: "public",
        favicon: "public/favicon.ico",
        templateParameters: {
          varAmbiente: varAmbiente,
        },
      }),
      new CopyWebpackPlugin({
        patterns: [
            { from: 'static', to: 'static' }
        ]
      }),
    ],
  });
};
