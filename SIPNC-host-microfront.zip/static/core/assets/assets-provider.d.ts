export declare function assetUrl(url: string, ativo: string): string;
