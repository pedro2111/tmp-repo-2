export declare function loadFontes(url: string): void;
