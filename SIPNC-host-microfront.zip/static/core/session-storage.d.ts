export declare function setSessionItem(key: string, value: any): void;
export declare function getSessionItem(key: string): any;
export declare function removeSessionItem(key: string): void;
export declare function clearSession(): void;
