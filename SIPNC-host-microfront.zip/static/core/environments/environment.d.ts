export declare const environment: {
    url: string;
    realm: string;
    clientId: string;
    redirect_uri: string;
};
