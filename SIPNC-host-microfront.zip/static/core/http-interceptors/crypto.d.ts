export declare function encryptAES(text: any): string;
