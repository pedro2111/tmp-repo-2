import { HttpEvent, HttpHandler, HttpRequest } from '@angular/common/http';
import { Observable } from 'rxjs';
export declare function interceptUtil(req: HttpRequest<any>, next: HttpHandler, keyCloackInstance: any): Observable<HttpEvent<any>>;
